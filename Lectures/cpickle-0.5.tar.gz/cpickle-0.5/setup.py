
raise RuntimeError("Package 'cpickle' must not be downloaded from pypi")
